package com.sk;

import Model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import repository.CustomerRepository;

@SpringBootApplication
public class CustomerCrudApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(CustomerCrudApplication.class, args);
	}

	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public void run(String... args) throws Exception {
		Customer customer = new Customer();
		customer.setFirst_name("Jane");
		customer.setLast_name("Doe");
		customer.setStreet("Elvnu Street");
		customer.setAddress("H.No.02");
		customer.setCity("Delhi");
		customer.setState("Delhi");
		customer.setEmail("jane@gmail");
		customer.setPhone(Integer.parseInt("22311334"));



	}
}
